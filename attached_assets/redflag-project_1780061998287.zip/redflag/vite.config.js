import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// During dev, the Vite server (5173) proxies /api to the Express server (3001).
// In production, Express serves the built files from /dist and the /api routes.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:3001",
    },
  },
  build: {
    outDir: "dist",
  },
});
