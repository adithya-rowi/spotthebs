# Spot the BS

Is the AI bluffing? Eight confident AI answers, half of them subtly wrong. Call the bluff. A tiny game to build the habit of checking the AI instead of surrendering to it.

Live: https://spotthebs.com

## Run on Replit

Hit **Run**. The `.replit` workflow runs `npm run build && node server.js` on port 5000. A PostgreSQL database is provisioned automatically; the server reads `DATABASE_URL` from the environment.

## Run locally

```bash
npm install
export DATABASE_URL=postgres://user:pass@localhost:5432/spotthebs
npm run dev      # Vite on :5173, API on :5000
```

## Install as a phone app (PWA)

Open the live site on a phone → **Share → Add to Home Screen**. It launches fullscreen with its own icon, no app store needed.

## How it works

- **Frontend**: a single React component (`src/RedFlag.jsx`), built with Vite.
- **Backend**: an Express server (`server.js`) with a PostgreSQL-backed leaderboard:
  - `GET  /api/leaderboard` → top scores
  - `POST /api/leaderboard` → submits `{ name, bestScore, surrenderRate }`, with server-side score-bound validation
- **Storage**: a `leaderboard` table (auto-created on startup).

## Scoring

| Outcome | Points |
| --- | --- |
| Catch a lie | +25 |
| Trust the truth | +10 |
| Buy a lie | −20 |
| Flag the truth | −5 |

After each game, the results screen shows your stats and a **"Where you went wrong"** review of every miss.

## Adding questions

Edit the `BANK` array in `src/RedFlag.jsx`. Keep the mix near 50/50 true/false so "always call BS" can't win:

```js
{
  domain: "Economics",
  q: "the question",
  ai: "the confident assistant answer",
  conf: 95,            // confidence shown, 88–99
  isCorrect: false,    // is the AI answer actually right?
  truth: "the real answer",
  why: "one line on the trap"
}
```
